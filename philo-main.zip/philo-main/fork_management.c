/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fork_management.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iunikel <marvin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 17:02:00 by iunikel           #+#    #+#             */
/*   Updated: 2025/03/30 22:41:01 by iunikel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

/* Fork handling functions */
int	take_forks(t_philo *p)
{
	int		first;
	int		second;
	long	max_wait;
	int		retry_count;
	int		is_starving;

	if (p->d->n_philo == 1)
	{
		pthread_mutex_lock(&p->d->f[p->left]);
		print_state(p, "has taken a fork");
		pthread_mutex_lock(&p->d->m);
		p->last_meal = get_time() - p->d->start; // Set last meal time to track death properly
		pthread_mutex_unlock(&p->d->m);
		
		// Hold the fork until the philosopher dies, but make sure it's eventually released
		precise_sleep(p->d->t_die / 2); // Sleep for half the death time
		if (!get_sim_state(p->d))
			precise_sleep(p->d->t_die / 2); // Sleep for the remaining time
		
		// Always release the fork before returning
		pthread_mutex_unlock(&p->d->f[p->left]);
		return (0);
	}
	
	if (get_sim_state(p->d))
		return (0);
		
	// Calculate maximum safe wait time and check if we're in starvation mode
	pthread_mutex_lock(&p->d->m);
	long current_time = get_time() - p->d->start;
	long time_since_meal = current_time - p->last_meal;
	long remaining_time = p->d->t_die - time_since_meal;
	
	is_starving = (remaining_time < (p->d->t_die * 0.3));
	max_wait = (p->d->t_die * 0.5) - time_since_meal;
	if (max_wait < 0)
		max_wait = 5; // Minimal time window for very hungry philosophers
	pthread_mutex_unlock(&p->d->m);
	
	// Always determine fork order with consistent rules across all paths
	// This ensures we maintain a consistent lock acquisition order
	first = p->left < p->right ? p->left : p->right;
	second = p->left < p->right ? p->right : p->left;
	
	// When starving, try very aggressively to get forks
	if (is_starving)
	{
		printf("DEBUG: Philo %d CRITICAL starvation (%ld ms remaining), aggressive fork strategy\n", 
			p->id, remaining_time);
		
		// Take first fork
		pthread_mutex_lock(&p->d->f[first]);
		print_state(p, "has taken a fork");
		
		// Take second fork immediately with blocking call
		pthread_mutex_lock(&p->d->f[second]);
		print_state(p, "has taken a fork");
		printf("DEBUG: Philo %d has both forks %d and %d (starving mode)\n", p->id, first, second);
		return (1);
	}
	
	// Normal case - try multiple times with backoff
	retry_count = 0;
	while (retry_count < 3 && !get_sim_state(p->d))
	{
		printf("DEBUG: Philo %d trying to take fork %d (attempt %d)\n", p->id, first, retry_count + 1);
		pthread_mutex_lock(&p->d->f[first]);
		print_state(p, "has taken a fork");
		
		// Try to take the second fork
		printf("DEBUG: Philo %d trying to take fork %d (attempt %d)\n", p->id, second, retry_count + 1);
		if (pthread_mutex_trylock(&p->d->f[second]) == 0)
		{
			// Success! Got both forks
			print_state(p, "has taken a fork");
			printf("DEBUG: Philo %d has both forks %d and %d\n", p->id, first, second);
			return (1);
		}
		
		// If we couldn't get the second fork, release the first and try again
		printf("DEBUG: Philo %d couldn't get second fork, releasing first\n", p->id);
		pthread_mutex_unlock(&p->d->f[first]);
		
		// Back off a bit before retrying, with a smaller delay for hungrier philosophers
		int backoff_time = 2;
		if (time_since_meal < p->d->t_die * 0.5)
			backoff_time = 2 + (p->id % 3);
			
		precise_sleep(backoff_time);
		retry_count++;
		
		// Recheck starvation status before next attempt
		pthread_mutex_lock(&p->d->m);
		time_since_meal = get_time() - p->d->start - p->last_meal;
		if (p->d->t_die - time_since_meal < (p->d->t_die * 0.3))
		{
			pthread_mutex_unlock(&p->d->m);
			printf("DEBUG: Philo %d entering starvation mode during retries\n", p->id);
			break; // Break out of retry loop and go to final attempt
		}
		pthread_mutex_unlock(&p->d->m);
	}
	
	if (!get_sim_state(p->d))
	{
		// Final attempt - blocking version
		printf("DEBUG: Philo %d final attempt for forks\n", p->id);
		
		pthread_mutex_lock(&p->d->f[first]);
		print_state(p, "has taken a fork");
		
		pthread_mutex_lock(&p->d->f[second]);
		print_state(p, "has taken a fork");
		printf("DEBUG: Philo %d has both forks %d and %d (final attempt)\n", p->id, first, second);
		return (1);
	}
	
	return (0);
}

void	release_forks(t_philo *p)
{
	int first;
	int second;
	
	if (p->d->n_philo == 1)
		return;
		
	// Use the same consistent ordering as in take_forks
	first = p->left < p->right ? p->left : p->right;
	second = p->left < p->right ? p->right : p->left;
	
	printf("DEBUG: Philo %d releasing forks %d and %d\n", p->id, second, first);
	
	// Release in reverse order of acquisition
	pthread_mutex_unlock(&p->d->f[second]);
	pthread_mutex_unlock(&p->d->f[first]);
}
