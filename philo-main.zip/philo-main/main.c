/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iunikel <marvin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 17:02:00 by iunikel           #+#    #+#             */
/*   Updated: 2025/03/30 19:54:55 by iunikel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

int	init_test_data(t_data *d)
{
	printf("DEBUG: Starting test with arguments: 4 410 200 200\n");
	d->n_philo = 4;
	d->t_die = 410;
	d->t_eat = 200;
	d->t_sleep = 200;
	d->n_meals = -1;  // No meal limit
	d->stop = 0;
	printf("DEBUG: Parameters - %d philos, die=%d, eat=%d, sleep=%d\n", 
		d->n_philo, d->t_die, d->t_eat, d->t_sleep);
	return (0);
}

int	run_debug_test(void)
{
	t_data	d;

	init_test_data(&d);
	printf("DEBUG: Initializing test simulation\n");
	if (init_simulation(&d))
	{
		printf("DEBUG: Failed to initialize simulation\n");
		return (1);
	}
	printf("DEBUG: Running test simulation\n");
	run_simulation(&d);
	printf("DEBUG: Cleaning up test simulation\n");
	cleanup_simulation(&d);
	return (0);
}

int	main(int argc, char **argv)
{
	t_data	d;

	if (argc == 2 && argv[1][0] == 'd' && argv[1][1] == '\0')
	{
		printf("DEBUG: Running special debug test case (4 410 200 200)\n");
		return (run_debug_test());
	}
	if (parse_args(argc, argv, &d))
	{
		printf("Error: invalid arguments\n");
		return (1);
	}
	if (init_simulation(&d))
	{
		printf("Error: failed to initialize simulation\n");
		return (1);
	}
	run_simulation(&d);
	cleanup_simulation(&d);
	return (0);
}
