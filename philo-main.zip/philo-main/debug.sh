#!/bin/bash

# Compile with debug symbols
make clean
make CFLAGS="-g -O0"

echo "=== Running special debug test ==="
./philo d

echo "=== Running with valgrind ==="
valgrind --tool=memcheck --leak-check=full --show-leak-kinds=all ./philo 4 410 200 200

echo "=== Running with helgrind ==="
valgrind --tool=helgrind ./philo 4 410 200 200

echo "=== Running with gdb ==="
gdb -ex "set pagination off" -ex "run 4 410 200 200" -ex "bt" -ex "quit" ./philo

echo "=== Testing with different configurations ==="
./philo 4 410 200 200
./philo 4 800 200 200
./philo 4 310 200 100 