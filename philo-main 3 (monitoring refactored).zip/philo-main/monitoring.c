/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitoring.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iunikel <marvin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 17:02:00 by iunikel           #+#    #+#             */
/*   Updated: 2025/03/31 15:21:27 by iunikel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

/* Monitoring functions */
static long	calculate_time_since_meal(long last, long current_time)
{
	if (last == 0)
		return (current_time);
	return (current_time - last);
}

static long	get_safety_margin(int single_philo)
{
	if (single_philo)
		return (0);
	return (2);
}

static int	handle_death(t_data *d, int i, long time)
{
	d->stop = 1;
	printf("%ld %d died\n", time, d->p[i].id);
	pthread_mutex_unlock(&d->m);
	return (1);
}

static int	check_single_philo_death(t_data *d, int i, long since, long time)
{
	if (since >= d->t_die && !d->stop)
		return (handle_death(d, i, time));
	return (0);
}

static int	check_multi_philo_death(t_data *d, int i, long since,
		long safety_margin, long time)
{
	if (since >= d->t_die + safety_margin && !d->stop)
		return (handle_death(d, i, time));
	return (0);
}

int	check_death(t_data *d, int i, long time)
{
	long	last;
	long	since;
	int		single_philo;
	long	safety_margin;
	int		result;

	pthread_mutex_lock(&d->m);
	last = d->p[i].last_meal;
	single_philo = (d->n_philo == 1);
	since = calculate_time_since_meal(last, time);
	safety_margin = get_safety_margin(single_philo);
	if (single_philo)
		result = check_single_philo_death(d, i, since, time);
	else
		result = check_multi_philo_death(d, i, since, safety_margin, time);
	if (result)
		return (1);
	pthread_mutex_unlock(&d->m);
	return (0);
}

int	check_meals_complete(t_data *d)
{
	int	i;
	int	meals;
	int	all;

	i = -1;
	all = 1;
	if (d->n_meals == -1)
		return (0);
	pthread_mutex_lock(&d->m);
	while (++i < d->n_philo && all)
	{
		meals = d->p[i].meals;
		if (meals < d->n_meals)
			all = 0;
	}
	if (all && !d->stop)
		d->stop = 1;
	pthread_mutex_unlock(&d->m);
	return (all);
}

void	dump_philo_states(t_data *d)
{
	int	i;

	i = 0;
	pthread_mutex_lock(&d->m);
	while (i < d->n_philo)
	{
		i++;
	}
	pthread_mutex_unlock(&d->m);
}

void	*monitor_routine(void *arg)
{
	t_data	*d;
	int		i;
	long	time;
	long	last_dump;

	d = (t_data *)arg;
	usleep(1000);
	last_dump = 0;
	while (!get_sim_state(d))
	{
		time = get_time() - d->start;
		if (time - last_dump >= 200)
		{
			dump_philo_states(d);
			last_dump = time;
		}
		i = -1;
		while (++i < d->n_philo)
			if (check_death(d, i, time))
				return (NULL);
		if (check_meals_complete(d))
			return (NULL);
		usleep(5000); // helgrind sleep
	}
	return (NULL);
}
