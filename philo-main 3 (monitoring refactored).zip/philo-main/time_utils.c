/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   time_utils.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iunikel <marvin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 17:02:00 by iunikel           #+#    #+#             */
/*   Updated: 2025/03/30 22:22:38 by iunikel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

/* Time utility functions */
long	get_time(void)
{
	struct timeval	tv;

	gettimeofday(&tv, NULL);
	return ((tv.tv_sec * 1000) + (tv.tv_usec / 1000));
}

int	precise_sleep(long ms)
{
	long	start;
	long	end;
	long	actual_sleep;
	long	elapsed;
	long	sleep_interval;

	start = get_time();
	while (1)
	{
		elapsed = get_time() - start;
		if (elapsed >= ms)
			break;
			
		// Use shorter sleep interval as we approach the target time
		// This reduces the risk of oversleeping
		sleep_interval = ms - elapsed;
		if (sleep_interval > 20)
			sleep_interval = 20;
		else if (sleep_interval > 0)
			sleep_interval = 1;
			
		usleep(sleep_interval * 100);  // Convert to microseconds but use smaller intervals
	}
	
	end = get_time();
	actual_sleep = end - start;
	
	if (actual_sleep > ms + 5)
		printf("DEBUG: Time drift in sleep - Target: %ld ms, Actual: %ld ms, Drift: %ld ms\n", 
			ms, actual_sleep, actual_sleep - ms);
	
	return (0);
}
