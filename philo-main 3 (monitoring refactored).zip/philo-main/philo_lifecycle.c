/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo_lifecycle.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iunikel <marvin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 17:02:00 by iunikel           #+#    #+#             */
/*   Updated: 2025/03/30 22:38:37 by iunikel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

/* Philosopher lifecycle functions */

int	philo_eat(t_philo *p)
{
	if (get_sim_state(p->d))
		return (0);
		
	// Check if we're close to starvation before trying to take forks
	pthread_mutex_lock(&p->d->m);
	long current_time = get_time() - p->d->start;
	long time_since_meal = current_time - p->last_meal;
	long time_remaining = p->d->t_die - time_since_meal;
	pthread_mutex_unlock(&p->d->m);
	
	// Prioritize eating when close to dying
	if (time_remaining < (p->d->t_die * 0.2))
		printf("DEBUG: Philo %d URGENT need to eat! Only %ld ms remaining\n", p->id, time_remaining);
		
	// Try to take forks
	if (!take_forks(p))
		return (0);
		
	// Update last_meal timestamp IMMEDIATELY after getting forks, before printing
	pthread_mutex_lock(&p->d->m);
	p->last_meal = get_time() - p->d->start;
	p->meals++;
	pthread_mutex_unlock(&p->d->m);
	
	// Now print eating state and increment meals
	print_state(p, "is eating");
	printf("DEBUG: Philo %d eating meal #%d at time %ld\n", 
		p->id, p->meals, p->last_meal);
	
	// Actually eat (sleep)
	precise_sleep(p->d->t_eat);
	
	// Release forks when done eating
	release_forks(p);
	return (1);
}

int	philo_sleep_think(t_philo *p)
{
	long	think_time;
	long	time_since_last_meal;
	long	current_time;
	long	time_remaining;

	if (get_sim_state(p->d))
		return (0);
	print_state(p, "is sleeping");
	printf("DEBUG: Philo %d sleeping for %d ms\n", p->id, p->d->t_sleep);
	precise_sleep(p->d->t_sleep);
	if (get_sim_state(p->d))
		return (0);
	print_state(p, "is thinking");
	
	// Calculate time since last meal to prioritize hungry philosophers
	pthread_mutex_lock(&p->d->m);
	current_time = get_time() - p->d->start;
	time_since_last_meal = current_time - p->last_meal;
	time_remaining = p->d->t_die - time_since_last_meal;
	pthread_mutex_unlock(&p->d->m);
	
	// If philosopher has less than 60% of their die time remaining, skip thinking
	if (time_remaining < (p->d->t_die * 0.6))
	{
		printf("DEBUG: Philo %d is hungry (last meal %ld ms ago, %ld ms remaining), skipping think time\n", 
			p->id, time_since_last_meal, time_remaining);
		return (1);
	}
	
	// For tight timing scenarios (where eat + sleep takes more than 80% of die time), don't think
	if (p->d->t_eat + p->d->t_sleep > p->d->t_die * 0.8)
	{
		printf("DEBUG: Philo %d in very tight timing scenario, skipping think time\n", p->id);
		return (1);
	}
	
	// Minimal thinking time for all other scenarios - just enough to break symmetry
	think_time = 3;
	if (p->id % 2 == 0) 
		think_time = 5;
	
	printf("DEBUG: Philo %d thinking for %ld ms\n", p->id, think_time);
	precise_sleep(think_time);
	
	return (1);
}

void	*philo_routine(void *arg)
{
	t_philo	*p;
	int		stop;

	p = (t_philo *)arg;
	pthread_mutex_lock(&p->d->m);
	p->last_meal = 0;
	pthread_mutex_unlock(&p->d->m);
	print_state(p, "is thinking");
	
	// Initial staggering based on ID to prevent all philosophers from trying to eat at once
	// This is especially important for philosophers with even IDs
	if (p->id % 2 == 0)
	{
		printf("DEBUG: Philo %d initial stagger delay\n", p->id);
		precise_sleep(5);  // Small delay for even numbered philosophers
	}
	
	while (1)
	{
		pthread_mutex_lock(&p->d->m);
		stop = p->d->stop;
		pthread_mutex_unlock(&p->d->m);
		if (stop)
			break ;
		if (!philo_eat(p))
			break ;
		if (!philo_sleep_think(p))
			break ;
	}
	return (NULL);
}
