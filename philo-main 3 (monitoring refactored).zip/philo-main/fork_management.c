/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   fork_management.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iunikel <marvin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 17:02:00 by iunikel           #+#    #+#             */
/*   Updated: 2025/03/31 13:52:32 by iunikel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

/* Fork handling functions */
static int	handle_single_fork(t_philo *p)
{
	pthread_mutex_lock(&p->d->f[p->left]);
	print_state(p, "has taken a fork");
	pthread_mutex_lock(&p->d->m);
	p->last_meal = get_time() - p->d->start;
	pthread_mutex_unlock(&p->d->m);
	precise_sleep(p->d->t_die / 2);
	if (!get_sim_state(p->d))
		precise_sleep(p->d->t_die / 2);
	pthread_mutex_unlock(&p->d->f[p->left]);
	return (0);
}

static int	try_starving_strategy(t_philo *p, int first, int second)
{
	long	remaining_time;

	pthread_mutex_lock(&p->d->m);
	remaining_time = p->d->t_die - (get_time() - p->d->start - p->last_meal);
	pthread_mutex_unlock(&p->d->m);
	printf("DEBUG: Philo %d CRITICAL starvation (%ld ms remaining),aggressive fork strategy\n", p->id, remaining_time);
	pthread_mutex_lock(&p->d->f[first]);
	print_state(p, "has taken a fork");
	pthread_mutex_lock(&p->d->f[second]);
	print_state(p, "has taken a fork");
	printf("DEBUG: Philo %d has both forks %d and %d (starving mode)\n", p->id,
		first, second);
	return (1);
}

static int	handle_starvation_check(t_philo *p, long *time_since_meal)
{
	long	remaining_time;

	pthread_mutex_lock(&p->d->m);
	*time_since_meal = get_time() - p->d->start - p->last_meal;
	remaining_time = p->d->t_die - *time_since_meal;
	pthread_mutex_unlock(&p->d->m);
	if (remaining_time < (p->d->t_die * 0.3))
		return (1);
	return (0);
}

static int	try_take_second_fork(t_philo *p, int first, int second)
{
	if (pthread_mutex_trylock(&p->d->f[second]) == 0)
	{
		print_state(p, "has taken a fork");
		printf("DEBUG: Philo %d has both forks %d and %d\n", p->id, first,
			second);
		return (1);
	}
	printf("DEBUG: Philo %d couldn't get second fork, releasing first\n",
		p->id);
	pthread_mutex_unlock(&p->d->f[first]);
	return (0);
}

static int	backoff_and_check(t_philo *p, long *time_since_meal)
{
	int	backoff_time;

	backoff_time = 2;
	if (*time_since_meal < p->d->t_die * 0.5)
		backoff_time = 2 + (p->id % 3);
	precise_sleep(backoff_time);
	pthread_mutex_lock(&p->d->m);
	*time_since_meal = get_time() - p->d->start - p->last_meal;
	if (p->d->t_die - *time_since_meal < (p->d->t_die * 0.3))
	{
		pthread_mutex_unlock(&p->d->m);
		printf("DEBUG: Philo %d entering starvation mode during retries\n",
			p->id);
		return (1);
	}
	pthread_mutex_unlock(&p->d->m);
	return (0);
}

static int	try_normal_strategy(t_philo *p, int first, int second,
		long time_since_meal)
{
	int	retry_count;

	retry_count = 0;
	while (retry_count < 3 && !get_sim_state(p->d))
	{
		printf("DEBUG: Philo %d trying to take fork %d (attempt %d)\n", p->id,
			first, retry_count + 1);
		pthread_mutex_lock(&p->d->f[first]);
		print_state(p, "has taken a fork");
		printf("DEBUG: Philo %d trying to take fork %d (attempt %d)\n", p->id,
			second, retry_count + 1);
		if (try_take_second_fork(p, first, second))
			return (1);
		retry_count++;
		if (backoff_and_check(p, &time_since_meal))
			return (2);
	}
	return (0);
}

static int	final_attempt(t_philo *p, int first, int second)
{
	printf("DEBUG: Philo %d final attempt for forks\n", p->id);
	pthread_mutex_lock(&p->d->f[first]);
	print_state(p, "has taken a fork");
	pthread_mutex_lock(&p->d->f[second]);
	print_state(p, "has taken a fork");
	printf("DEBUG: Philo %d has both forks %d and %d (final attempt)\n", p->id,
		first, second);
	return (1);
}

static void	get_fork_order(t_philo *p, int *first, int *second)
{
	if (p->left < p->right)
	{
		*first = p->left;
		*second = p->right;
	}
	else
	{
		*first = p->right;
		*second = p->left;
	}
}

int	take_forks(t_philo *p)
{
	int		first;
	int		second;
	long	time_since_meal;
	int		result;

	if (p->d->n_philo == 1)
		return (handle_single_fork(p));
	if (get_sim_state(p->d))
		return (0);
	get_fork_order(p, &first, &second);
	if (handle_starvation_check(p, &time_since_meal))
		return (try_starving_strategy(p, first, second));
	result = try_normal_strategy(p, first, second, time_since_meal);
	if (result == 1)
		return (1);
	if (result == 2)
		return (try_starving_strategy(p, first, second));
	if (!get_sim_state(p->d))
		return (final_attempt(p, first, second));
	return (0);
}

void	release_forks(t_philo *p)
{
	int	first;
	int	second;

	if (p->d->n_philo == 1)
		return ;
	if (p->left < p->right)
	{
		first = p->left;
		second = p->right;
	}
	else
	{
		first = p->right;
		second = p->left;
	}
	printf("DEBUG: Philo %d releasing forks %d and %d\n", p->id, second, first);
	pthread_mutex_unlock(&p->d->f[second]);
	pthread_mutex_unlock(&p->d->f[first]);
}
