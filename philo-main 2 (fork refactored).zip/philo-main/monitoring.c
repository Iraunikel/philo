/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   monitoring.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: iunikel <marvin@student.42.fr>             +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 17:02:00 by iunikel           #+#    #+#             */
/*   Updated: 2025/03/30 22:41:19 by iunikel          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "philo.h"

/* Monitoring functions */
int	check_death(t_data *d, int i, long time)
{
	long	last;
	long	since;
	int		single_philo;
	long	safety_margin;

	pthread_mutex_lock(&d->m);
	last = d->p[i].last_meal;
	single_philo = (d->n_philo == 1);
	
	if (last == 0)
		since = time;
	else
		since = time - last;
	
	// Add a very small safety margin for non-single philosopher cases
	// This prevents deaths due to timing issues
	safety_margin = single_philo ? 0 : 2;
	
	// Handle single philosopher case specially
	if (single_philo && since >= d->t_die && !d->stop)
	{
		d->stop = 1;
		printf("%ld %d died\n", time, d->p[i].id);
		printf("DEBUG: Single philo %d died - Time: %ld, Last meal: %ld, Time since last meal: %ld, Die time: %d\n", 
			d->p[i].id, time, last, since, d->t_die);
		pthread_mutex_unlock(&d->m);
		return (1);
	}
	// Regular case for multiple philosophers - add safety margin
	else if (!single_philo && since >= d->t_die + safety_margin && !d->stop)
	{
		d->stop = 1;
		printf("%ld %d died\n", time, d->p[i].id);
		printf("DEBUG: Philo %d died - Time: %ld, Last meal: %ld, Time since last meal: %ld, Die time: %d\n", 
			d->p[i].id, time, last, since, d->t_die);
		pthread_mutex_unlock(&d->m);
		return (1);
	}
	pthread_mutex_unlock(&d->m);
	return (0);
}

int	check_meals_complete(t_data *d)
{
	int	i;
	int	meals;
	int	all;

	i = -1;
	all = 1;
	if (d->n_meals == -1)
		return (0);
	pthread_mutex_lock(&d->m);
	while (++i < d->n_philo && all)
	{
		meals = d->p[i].meals;
		if (meals < d->n_meals)
			all = 0;
	}
	if (all && !d->stop)
		d->stop = 1;
	pthread_mutex_unlock(&d->m);
	return (all);
}

void	dump_philo_states(t_data *d, long time)
{
	int		i;
	long	last_meal_time;
	long	time_since_meal;

	i = 0;
	printf("\n------ PHILO STATE DUMP AT TIME %ld ------\n", time);
	pthread_mutex_lock(&d->m);
	while (i < d->n_philo)
	{
		last_meal_time = d->p[i].last_meal;
		if (last_meal_time == 0)
			time_since_meal = time;
		else
			time_since_meal = time - last_meal_time;
			
		printf("Philo %d: meals=%d, last_meal=%ld, time_since_meal=%ld/%d\n", 
			d->p[i].id, d->p[i].meals, last_meal_time, 
			time_since_meal, d->t_die);
		i++;
	}
	printf("------ END STATE DUMP ------\n\n");
	pthread_mutex_unlock(&d->m);
}

void	*monitor_routine(void *arg)
{
	t_data	*d;
	int		i;
	long	time;
	long	last_dump;

	d = (t_data *)arg;
	usleep(1000);
	last_dump = 0;
	while (!get_sim_state(d))
	{
		time = get_time() - d->start;
		
		// Dump state every 200ms
		if (time - last_dump >= 200) 
		{
			dump_philo_states(d, time);
			last_dump = time;
		}
		
		i = -1;
		while (++i < d->n_philo)
			if (check_death(d, i, time))
				return (NULL);
		if (check_meals_complete(d))
			return (NULL);
		
		// Sleep a bit longer (5ms) to reduce overhead when running under helgrind
		// Still short enough to detect death accurately
		usleep(5000);
	}
	return (NULL);
}
